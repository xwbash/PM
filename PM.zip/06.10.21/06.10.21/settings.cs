﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace _06._10._21
{
    static class settings
    {
       static string SunucuID = "DESKTOP-NE6PQ05\\SQLEXPRESS";

       static string data = ("Data Source="+SunucuID+";Initial Catalog=Project_Manisa;Integrated Security=True; MultipleActiveResultSets=True");
       public static string ConnectServer{ get { return data; } }
    }
}
