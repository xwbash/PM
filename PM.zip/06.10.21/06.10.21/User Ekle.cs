﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _06._10._21
{
    public partial class User_Ekle : Form
    {
       
        SqlConnection connect = new SqlConnection(settings.ConnectServer);
        SqlDataReader reader, readerr;
        SqlCommand command;
        public User_Ekle()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Admin_Panel admin_Paneli = new Admin_Panel();
            admin_Paneli.Show();
            this.Visible = false;
        }

        private void User_Ekle_Load(object sender, EventArgs e)
        {
            this.CenterToParent();
            string Sql = "select isim from roller";
            SqlConnection connect = new SqlConnection(settings.ConnectServer);
            connect.Open();
            command = new SqlCommand(Sql, connect);
            reader = command.ExecuteReader();

            while (reader.Read())
            {
                comboBox1.Items.Add(reader[0]);

            }
            Sql = "select depNam from departman";
            command = new SqlCommand(Sql, connect);
            readerr = command.ExecuteReader();

            while (readerr.Read())
            {
                comboBox2.Items.Add(readerr[0]);

            }
            Sql = "SELECT MAX(PersonID) from users";
            command = new SqlCommand(Sql, connect);
            reader = command.ExecuteReader();
            if (reader.Read())
            {
                ReadSingleRow((IDataRecord)reader);
            }

        }
        private void ReadSingleRow(IDataRecord dataRecord)
        {
            textBox1.Text = Convert.ToString(Convert.ToInt32(dataRecord[0]) + 1);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string rol = comboBox1.SelectedItem.ToString();
            string dep = comboBox2.SelectedItem.ToString();
            string rolid="2", depid="2";
            connect.Open();
            command = new SqlCommand("select id from roller where isim='" + rol + "'", connect);
            reader = command.ExecuteReader();
            if(reader.Read())
            {
                rolid = reader["id"].ToString();
            }
            command = new SqlCommand("select depID from departman where depNam='" + dep + "'", connect);
            reader = command.ExecuteReader();
            if (reader.Read())
            {
                depid = reader["depID"].ToString();
            }

            command = new SqlCommand("INSERT INTO users(PersonID,eposta,rolID,depID,name,surname,tel) VALUES(@param1,@param2,@param3,@param4,@param5,@param6,@param7)", connect);
            command.Parameters.AddWithValue("@param1", textBox1.Text);
            command.Parameters.AddWithValue("@param2", textBox2.Text);
            command.Parameters.AddWithValue("@param3", rolid);
            command.Parameters.AddWithValue("@param4", depid);
            command.Parameters.AddWithValue("@param5", textBox5.Text);
            command.Parameters.AddWithValue("@param6", textBox6.Text);
            command.Parameters.AddWithValue("@param7", textBox7.Text);
            command.ExecuteNonQuery();
            Admin_Panel admin = new Admin_Panel();
            admin.Visible = true;
            this.Visible = false;
        }
    }
}
